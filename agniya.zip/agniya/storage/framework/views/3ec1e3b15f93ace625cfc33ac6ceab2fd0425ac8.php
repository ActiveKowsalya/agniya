<!DOCTYPE html>
<html>
    <head>
        <title>Oracle NetSuite</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/form_base_css.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/felxbox-global.css')); ?>">
        <link rel='icon' href="<?php echo e(asset('images/icon.ico')); ?>"  type='' sizes="16x16" />
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
#phone, #firstname, #lastname, #email, #companyname{border: 0px;
width: 100%;}
.success{  text-align: right;
  color: green;
  font-weight: 600;
}
.error{
    text-align: right;
color: red;
font-weight: 600;
}
</style>
    </head>
    <body>
        <header>

            <div class="container">
                <img src="<?php echo e(asset('images/logo-oracle.png')); ?>" alt="Oracle NetSuite" class="logo">
                <h1><span class="block">NetSuite:</span> The #1 Cloud ERP Software</h1>
                <h2>Trusted by More Than <span id="nlCustomerCount" name="en-US">33,000 Customers</span> Worldwide</h2>
            </div>
        </header>
        

            <main class="container">
                <div class="form-wrap">
                    <h3>Almost there! To begin your <strong>FREE PRODUCT TOUR</strong> of NetSuite, please complete the form:</h3>

                    <?php if(isset($result['status'])=='Success'): ?>
                    <p class="success"><?php echo e($result['message']); ?></p>
                    <?php elseif(isset($result['status'])=='Failure'): ?>
                    <p class="error"><?php echo e($result['message']); ?></p>
                    <?php endif; ?>

                    <form id="main_form" name="main_form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('/insert-form')); ?>" style="margin: 0">
                    <?php echo e(csrf_field()); ?>

                        <div class="form-group wd-50">
                            <label for="firstname">First Name*</label>
                            <span style="white-space: nowrap" id="firstname_fs" class="effectStatic" data-fieldtype=""><input size="25" aria-labelledby="firstname_fs_lbl" name="firstname" id="firstname" class="inputreq" required /></span>
                        </div>
        
                        <div class="form-group wd-50">
                            <label for="lastname">Last Name*</label>
                            <span style="white-space: nowrap" id="lastname_fs" class="effectStatic" data-fieldtype=""><input size="25" aria-labelledby="lastname_fs_lbl" name="lastname" id="lastname" class="inputreq" required></span>
                        </div>
        
                        <div class="form-group wd-50">
                            <label for="email">Work Email*</label>
                            <span style="white-space: nowrap" id="email_fs" class="effectStatic" data-fieldtype=""><input size="25" aria-labelledby="email_fs_lbl" name="email" id="email" class="inputreq" required></span>
                        </div>
        
                        <div class="form-group wd-50">
                            <label for="phone">Phone*</label>
                            <span style="white-space: nowrap" id="phone_fs" class="effectStatic" data-fieldtype="">
                                <input  size="25" aria-labelledby="phone_fs_lbl" name="phone"  id="phone" class="inputreq" pattern="[789][0-9]{9}" required></span>
                        </div>
        
                        <div class="form-group wd-50">
                            <label for="companyname">Company*</label>
                            <span style="white-space: nowrap" id="companyname_fs" class="effectStatic" data-fieldtype=""><input  size="25" aria-labelledby="companyname_fs_lbl" name="companyname" id="companyname" class="inputreq" required></span>
                        </div>
        
                        <div class="form-group wd-50">
                            <label for="country">Country*</label>
                            <span id="country_fs" data-fieldtype="select" class="" style="white-space: nowrap;">
        <select name="country" id="country" class="inputreq" flags="2267742732416" type="select-one" required >
        <option value="" selected=""></option>
        <option value="US">United States</option>
        <option value="AF">Afghanistan</option>
        <option value="AX">Aland Islands</option>
        <option value="AL">Albania</option>
        <option value="DZ">Algeria</option>
        <option value="AS">American Samoa</option>
        <option value="AD">Andorra</option>
        <option value="AO">Angola</option>
        <option value="AI">Anguilla</option>
        <option value="AQ">Antarctica</option>
        <option value="AG">Antigua and Barbuda</option>
        <option value="AR">Argentina</option>
        <option value="AM">Armenia</option>
        <option value="AW">Aruba</option>
        <option value="AU">Australia</option>
        <option value="AT">Austria</option>
        <option value="AZ">Azerbaijan</option>
        <option value="BS">Bahamas</option>
        <option value="BH">Bahrain</option>
        <option value="BD">Bangladesh</option>
        <option value="BB">Barbados</option>
        <option value="BY">Belarus</option>
        <option value="BE">Belgium</option>
        <option value="BZ">Belize</option>
        <option value="BJ">Benin</option>
        <option value="BM">Bermuda</option>
        <option value="BT">Bhutan</option>
        <option value="BO">Bolivia</option>
        <option value="BQ">Bonaire, Saint Eustatius and Saba</option>
        <option value="BA">Bosnia and Herzegovina</option>
        <option value="BW">Botswana</option>
        <option value="BV">Bouvet Island</option>
        <option value="BR">Brazil</option>
        <option value="IO">British Indian Ocean Territory</option>
        <option value="BN">Brunei Darussalam</option>
        <option value="BG">Bulgaria</option>
        <option value="BF">Burkina Faso</option>
        <option value="BI">Burundi</option>
        <option value="KH">Cambodia</option>
        <option value="CM">Cameroon</option>
        <option value="CA">Canada</option>
        <option value="IC">Canary Islands</option>
        <option value="CV">Cape Verde</option>
        <option value="KY">Cayman Islands</option>
        <option value="CF">Central African Republic</option>
        <option value="EA">Ceuta and Melilla</option>
        <option value="TD">Chad</option>
        <option value="CL">Chile</option>
        <option value="CN">China</option>
        <option value="CX">Christmas Island</option>
        <option value="CC">Cocos (Keeling) Islands</option>
        <option value="CO">Colombia</option>
        <option value="KM">Comoros</option>
        <option value="CD">Congo, Democratic Republic of</option>
        <option value="CG">Congo, Republic of</option>
        <option value="CK">Cook Islands</option>
        <option value="CR">Costa Rica</option>
        <option value="CI">Cote d'Ivoire</option>
        <option value="HR">Croatia/Hrvatska</option>
        <option value="CU">Cuba</option>
        <option value="CW">Curaçao</option>
        <option value="CY">Cyprus</option>
        <option value="CZ">Czech Republic</option>
        <option value="DK">Denmark</option>
        <option value="DJ">Djibouti</option>
        <option value="DM">Dominica</option>
        <option value="DO">Dominican Republic</option>
        <option value="TL">East Timor</option>
        <option value="EC">Ecuador</option>
        <option value="EG">Egypt</option>
        <option value="SV">El Salvador</option>
        <option value="GQ">Equatorial Guinea</option>
        <option value="ER">Eritrea</option>
        <option value="EE">Estonia</option>
        <option value="ET">Ethiopia</option>
        <option value="FK">Falkland Islands</option>
        <option value="FO">Faroe Islands</option>
        <option value="FJ">Fiji</option>
        <option value="FI">Finland</option>
        <option value="FR">France</option>
        <option value="GF">French Guiana</option>
        <option value="PF">French Polynesia</option>
        <option value="TF">French Southern Territories</option>
        <option value="GA">Gabon</option>
        <option value="GM">Gambia</option>
        <option value="GE">Georgia</option>
        <option value="DE">Germany</option>
        <option value="GH">Ghana</option>
        <option value="GI">Gibraltar</option>
        <option value="GR">Greece</option>
        <option value="GL">Greenland</option>
        <option value="GD">Grenada</option>
        <option value="GP">Guadeloupe</option>
        <option value="GU">Guam</option>
        <option value="GT">Guatemala</option>
        <option value="GG">Guernsey</option>
        <option value="GN">Guinea</option>
        <option value="GW">Guinea-Bissau</option>
        <option value="GY">Guyana</option>
        <option value="HT">Haiti</option>
        <option value="HM">Heard and McDonald Islands</option>
        <option value="VA">Holy See (City Vatican State)</option>
        <option value="HN">Honduras</option>
        <option value="HK">Hong Kong</option>
        <option value="HU">Hungary</option>
        <option value="IS">Iceland</option>
        <option value="IN">India</option>
        <option value="ID">Indonesia</option>
        <option value="IR">Iran (Islamic Republic of)</option>
        <option value="IQ">Iraq</option>
        <option value="IE">Ireland</option>
        <option value="IM">Isle of Man</option>
        <option value="IL">Israel</option>
        <option value="IT">Italy</option>
        <option value="JM">Jamaica</option>
        <option value="JP">Japan</option>
        <option value="JE">Jersey</option>
        <option value="JO">Jordan</option>
        <option value="KZ">Kazakhstan</option>
        <option value="KE">Kenya</option>
        <option value="KI">Kiribati</option>
        <option value="KP">Korea, Democratic People's Republic</option>
        <option value="KR">Korea, Republic of</option>
        <option value="XK">Kosovo</option>
        <option value="KW">Kuwait</option>
        <option value="KG">Kyrgyzstan</option>
        <option value="LA">Lao People's Democratic Republic</option>
        <option value="LV">Latvia</option>
        <option value="LB">Lebanon</option>
        <option value="LS">Lesotho</option>
        <option value="LR">Liberia</option>
        <option value="LY">Libya</option>
        <option value="LI">Liechtenstein</option>
        <option value="LT">Lithuania</option>
        <option value="LU">Luxembourg</option>
        <option value="MO">Macau</option>
        <option value="MK">Macedonia</option>
        <option value="MG">Madagascar</option>
        <option value="MW">Malawi</option>
        <option value="MY">Malaysia</option>
        <option value="MV">Maldives</option>
        <option value="ML">Mali</option>
        <option value="MT">Malta</option>
        <option value="MH">Marshall Islands</option>
        <option value="MQ">Martinique</option>
        <option value="MR">Mauritania</option>
        <option value="MU">Mauritius</option>
        <option value="YT">Mayotte</option>
        <option value="MX">Mexico</option>
        <option value="FM">Micronesia, Federal State of</option>
        <option value="MD">Moldova, Republic of</option>
        <option value="MC">Monaco</option>
        <option value="MN">Mongolia</option>
        <option value="ME">Montenegro</option>
        <option value="MS">Montserrat</option>
        <option value="MA">Morocco</option>
        <option value="MZ">Mozambique</option>
        <option value="MM">Myanmar (Burma)</option>
        <option value="NA">Namibia</option>
        <option value="NR">Nauru</option>
        <option value="NP">Nepal</option>
        <option value="NL">Netherlands</option>
        <option value="AN">Netherlands Antilles (Deprecated)</option>
        <option value="NC">New Caledonia</option>
        <option value="NZ">New Zealand</option>
        <option value="NI">Nicaragua</option>
        <option value="NE">Niger</option>
        <option value="NG">Nigeria</option>
        <option value="NU">Niue</option>
        <option value="NF">Norfolk Island</option>
        <option value="MP">Northern Mariana Islands</option>
        <option value="NO">Norway</option>
        <option value="OM">Oman</option>
        <option value="PK">Pakistan</option>
        <option value="PW">Palau</option>
        <option value="PA">Panama</option>
        <option value="PG">Papua New Guinea</option>
        <option value="PY">Paraguay</option>
        <option value="PE">Peru</option>
        <option value="PH">Philippines</option>
        <option value="PN">Pitcairn Island</option>
        <option value="PL">Poland</option>
        <option value="PT">Portugal</option>
        <option value="PR">Puerto Rico</option>
        <option value="QA">Qatar</option>
        <option value="RE">Reunion Island</option>
        <option value="RO">Romania</option>
        <option value="RU">Russian Federation</option>
        <option value="RW">Rwanda</option>
        <option value="BL">Saint Barthélemy</option>
        <option value="SH">Saint Helena</option>
        <option value="KN">Saint Kitts and Nevis</option>
        <option value="LC">Saint Lucia</option>
        <option value="MF">Saint Martin</option>
        <option value="VC">Saint Vincent and the Grenadines</option>
        <option value="WS">Samoa</option>
        <option value="SM">San Marino</option>
        <option value="ST">Sao Tome and Principe</option>
        <option value="SA">Saudi Arabia</option>
        <option value="SN">Senegal</option>
        <option value="RS">Serbia</option>
        <option value="CS">Serbia and Montenegro (Deprecated)</option>
        <option value="SC">Seychelles</option>
        <option value="SL">Sierra Leone</option>
        <option value="SG">Singapore</option>
        <option value="SX">Sint Maarten</option>
        <option value="SK">Slovak Republic</option>
        <option value="SI">Slovenia</option>
        <option value="SB">Solomon Islands</option>
        <option value="SO">Somalia</option>
        <option value="ZA">South Africa</option>
        <option value="GS">South Georgia</option>
        <option value="SS">South Sudan</option>
        <option value="ES">Spain</option>
        <option value="LK">Sri Lanka</option>
        <option value="PM">St. Pierre and Miquelon</option>
        <option value="PS">State of Palestine</option>
        <option value="SD">Sudan</option>
        <option value="SR">Suriname</option>
        <option value="SJ">Svalbard and Jan Mayen Islands</option>
        <option value="SZ">Swaziland</option>
        <option value="SE">Sweden</option>
        <option value="CH">Switzerland</option>
        <option value="SY">Syrian Arab Republic</option>
        <option value="TW">Taiwan</option>
        <option value="TJ">Tajikistan</option>
        <option value="TZ">Tanzania</option>
        <option value="TH">Thailand</option>
        <option value="TG">Togo</option>
        <option value="TK">Tokelau</option>
        <option value="TO">Tonga</option>
        <option value="TT">Trinidad and Tobago</option>
        <option value="TN">Tunisia</option>
        <option value="TR">Turkey</option>
        <option value="TM">Turkmenistan</option>
        <option value="TC">Turks and Caicos Islands</option>
        <option value="TV">Tuvalu</option>
        <option value="UM">US Minor Outlying Islands</option>
        <option value="UG">Uganda</option>
        <option value="UA">Ukraine</option>
        <option value="AE">United Arab Emirates</option>
        <option value="GB">United Kingdom</option>
        <option value="UY">Uruguay</option>
        <option value="UZ">Uzbekistan</option>
        <option value="VU">Vanuatu</option>
        <option value="VE">Venezuela</option>
        <option value="VN">Vietnam</option>
        <option value="VG">Virgin Islands (British)</option>
        <option value="VI">Virgin Islands (USA)</option>
        <option value="WF">Wallis and Futuna</option>
        <option value="EH">Western Sahara</option>
        <option value="YE">Yemen</option>
        <option value="ZM">Zambia</option>
        <option value="ZW">Zimbabwe</option>
        </select>
        <span class="field_widget_helper_pos effectStatic"></span></span>
                        </div>
        
                        <div class="form-group wd-50">
                            <label for="custentity11">How did you hear about us?*</label>
                            <span id="custentity11_fs" data-fieldtype="select" class="" style="white-space: nowrap;">
        <select name="custentity11" id="custentity11" class="inputreq" flags="2268816605312" type="select-one"  required>
        <option value="" selected=""></option>
        <option value="102">Affiliate</option>
        <option value="1">Direct Mail</option>
        <option value="2">Email</option>
        <option value="27">Event</option>
        <option value="3">Friend/Associate/Accountant</option>
        <option value="25">NetSuite Website</option>
        <option value="104">News Article</option>
        <option value="20">Online Ads</option>
        <option value="30">Podcast</option>
        <option value="101">Print</option>
        <option value="5">Radio</option>
        <option value="6">Search</option>
        <option value="26">Social Media</option>
        <option value="29">Video</option>
        <option value="11">Webinar</option>
        </select>
        <span class="field_widget_helper_pos effectStatic"></span></span>
                        </div>
        
                        <div class="form-group wd-50">
                            <label for="custentity_product_need">What is your primary business system need?*</label>
                            <span id="custentity_product_need_fs" data-fieldtype="select" class="" style="white-space: nowrap;">
        <select name="custentity_product_need" id="custentity_product_need" class="inputreq" required >
        <option value="" selected=""></option>
        <option value="10">Accounting / Financials</option>
        <option value="3">CRM</option>
        <option value="4">Ecommerce</option>
        <option value="2">ERP</option>
        <option value="6">Global &amp; multi-company management</option>
        <option value="9">Human Resources</option>
        <option value="1">Integrated Business Software Suite</option>
        <option value="8">Order Management</option>
        <option value="7">POS / Retail Software</option>
        <option value="5">Professional Services Automation</option>
        </select>
        <span class="field_widget_helper_pos effectStatic"></span></span>
                        </div>
        
                        <div class="form-group wd-50">
                            <label for="custentity2">Type of Business*</label>
                            <span id="custentity2_fs" data-fieldtype="select" class="" style="white-space: nowrap;">
        <select name="custentity2" id="custentity2" class="inputreq" type="select-one" valuewhenrendered="" aria-labelledby="custentity2_fs_lbl" required >
        <option value="" selected=""></option>
        <option value="2">Advertising &amp; Marketing Services</option>
        <option value="4">Agriculture</option>
        <option value="5">Apparel, Footwear &amp; Accessories (AFA)</option>
        <option value="9">Biotech &amp; Pharmaceuticals</option>
        <option value="10">Cloud Computing / Web-based Software</option>
        <option value="12">Computer &amp; IT Services</option>
        <option value="15">Computer Software</option>
        <option value="16">Construction &amp; Contracting</option>
        <option value="17">Consulting Services</option>
        <option value="20">Distribution &amp; Wholesale</option>
        <option value="23">eCommerce</option>
        <option value="24">Education</option>
        <option value="25">Energy / Utilities</option>
        <option value="26">Engineering, Architecture &amp; Design</option>
        <option value="27">Finance, Accounting &amp; Insurance</option>
        <option value="28">Food &amp; Beverage Distributor</option>
        <option value="29">Food &amp; Beverage Manufacturer</option>
        <option value="30">Government</option>
        <option value="31">Health &amp; Beauty</option>
        <option value="33">Healthcare Services</option>
        <option value="36">IT Developer / Reseller / VAR</option>
        <option value="39">Logistic &amp; Transportation Services</option>
        <option value="40">Manufacturing</option>
        <option value="42">Media/Publishing</option>
        <option value="44">Nonprofit</option>
        <option value="46">Professional Services</option>
        <option value="47">Real Estate</option>
        <option value="48">Restaurant &amp; Hospitality</option>
        <option value="49">Retail</option>
        <option value="54">Services : Other</option>
        <option value="56">Telecommunications</option>
        </select>
        <span class="field_widget_helper_pos effectStatic"></span></span>
                        </div>
        
                        <div class="form-group wd-50">
                            <label for="custentity9">Your Role*</label>
                            <span id="custentity9_fs" data-fieldtype="select" class="" style="white-space: nowrap;">
        <select name="custentity9" id="custentity9" class="inputreq" required >
        <option value="" selected=""></option>
        <option value="1">CEO/President/GM</option>
        <option value="2">CFO</option>
        <option value="3">CIO/IT Executive</option>
        <option value="4">Compliance/Security</option>
        <option value="5">Controller/Finance Executive</option>
        <option value="6">COO/Operations Executive</option>
        <option value="7">Customer Service/Support Manager</option>
        <option value="101">Developer</option>
        <option value="8">Ecommerce Developer/Designer</option>
        <option value="9">Ecommerce Executive/Manager</option>
        <option value="10">Executive (Others)</option>
        <option value="11">Finance (Others)</option>
        <option value="12">Finance/Accounting Manager</option>
        <option value="102">FP&amp;A VP/Director/Manager</option>
        <option value="13">Human Resources</option>
        <option value="14">IT (Others)</option>
        <option value="15">IT Manager</option>
        <option value="16">Manager (Others)</option>
        <option value="17">Marketing Executive/Brand Manager</option>
        <option value="103">Operations (Other)</option>
        <option value="20">Others</option>
        <option value="21">Procurement</option>
        <option value="22">Professional Services Executive</option>
        <option value="23">Professional Services Manager</option>
        <option value="24">Project Manager</option>
        <option value="26">Sales Executive</option>
        </select>
        <span class="field_widget_helper_pos effectStatic"></span></span>
                        </div>
        
                        <div class="privacy">
                            <span id="orclOptInPrivacy"><div class="form-label" id="regOptIn" style="display: block;"> <input class="form-field" id="receivedMktgEmail1Dummy" name="receivedMktgEmail1Dummy" type="checkbox" value="" required> <input id="receivedMktgEmail1" name="receivedMktgEmail1" type="hidden" value=""> <span><label for="receivedMktgEmail1Dummy">Yes, send me marketing communications on Oracle Products, Services and Events.</label></span></div>
                            
                       
                          
                          <div class="optInBlock prvShared" id="prvUS" style="display: block;"> <br> By filling and submitting this form you understand and agree that the use of Oracle's web site is subject to the <a href="https://www.oracle.com/us/legal/terms/index.html" target="_blank">Oracle.com Terms of Use</a>. Additional details regarding Oracle’s collection and use of your personal information, including information about access, retention, rectification, deletion, security, cross-border transfers and other topics, is available in the <a href="https://www.oracle.com/us/legal/privacy/privacy-policy/index.html" target="_blank">Oracle Privacy Policy</a>.</div>
                          
                          
                      
                        </div>
        
                        <input type="submit" name="submit2" value="Get My Free Product Tour">
                        
        
        <!-- END OF REQUIRED HIDDEN FIELDS FOR HTML ONLINE FORM -->
        </form>
        
                </div>
        
              <section class="container customers" style="margin-top: 50px;">
                  <h3>Industry leaders who rely on NetSuite:</h3>
                  <div class="customer-logos flex">
                      <img src="<?php echo e(asset('images/logo-Groupon.png')); ?>" alt="Groupon">
                      <img src="<?php echo e(asset('images/logo-discovery.png')); ?>" alt="Discovery">
                      <img src="<?php echo e(asset('images/logo-Threadup.png')); ?>" alt="Thread Up">
                      <img src="<?php echo e(asset('images/logo-LLS.png')); ?>" alt="Leukemia and Lymphoma Society">
                      <img src="<?php echo e(asset('images/logo-SSC.png')); ?>" alt="SSC Advent">
                  </div>
              </section>
        
                <section class="features">
                    <h3>With NetSuite’s cloud ERP system you can:</h3>
                    <div class="flex">
                        <div class="feature purple">
                            <div class="img-disc"></div>
                            <h4>Reduce manual</h4>
                            <p>and spreadsheet-based processes by up to 70%, by using one back office system including financials, fulfillment, inventory and sales.</p>
                        </div>
                        <div class="feature green">
                            <div class="img-disc"></div>
                            <h4>Gain daily cash balance</h4>
                            <p>visibility, using real-time dashboards, scorecards and KPI’s.</p>
                        </div>
                        <div class="feature orange">
                            <div class="img-disc"></div>
                            <h4>Save up to 93%</h4>
                            <p>in IT costs associated with maintaining, integrating and upgrading separate applications.</p>
                        </div>
                        <div class="feature blue">
                            <div class="img-disc"></div>
                            <h4>Real-time visibility</h4>
                            <p>across the business, with 24/7 access from any browser.</p>
                        </div>
                    </div>
                </section>
              
            </main>
            <section class="testimonials">
		<div class="container flex">
			<div class="quote">
				<p>"We share the vision NetSuite has that the cloud is the future of information systems, particularly for those who don’t have endless resources to hire and retain top-tier IT talent. At just a fraction of the cost of keeping SAP, NetSuite provides us a solution that is much more flexible and dynamic."</p>
				<p>— Kurt Liebich, CEO, Redbuilt LLC</p>
			</div>
			<div class="quote">
				<p>"NetSuite made the technical aspects of our implementation ridiculously easy, and were valuable partners in helping us understand our requirements and processes. If we had selected a lighter-weight system, we would never have gotten off the ground, and if we had paid for a conventional on-premise ERP system, we would not have survived long enough to implement it."</p>
				<p>— Beyond The Rack</p>
			</div>
		</div>
	</section>
    <section class="container codie">
		<h3>NetSuite is the fastest growing <span class="block">top 10 financial management system</span> globally for the third straight year.</h3>
		<p>
			<img src="<?php echo e(asset('images/CODIE_2015_winner_black_small.png')); ?>" alt="Codie">
			<img src="<?php echo e(asset('images/bnr-chart-gartner-black-small.png')); ?>" alt="Gartner Chart">
		</p>
	</section>
        <footer>

            <div class="container">
				<span id="orclFoooter"><a href="https://www.oracle.com/legal/copyright.html" target="_blank">© Oracle</a> | <a href="https://www.oracle.com/legal/privacy/index.html" target="_blank">Terms of Use and Privacy</a> | <span id="teconsent">&nbsp;</span></span>
		</div>
        </footer>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Task\agniya\resources\views/welcome.blade.php ENDPATH**/ ?>