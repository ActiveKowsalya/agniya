<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SuiteForm extends Model
{
    use HasFactory;
   
    protected $table = 'suiteform';

    protected $fillable = [
        'id', 'firstname','lastname','email','phone','companyname','country','custentity11','custentity_product_need','custentity2','custentity9'
    ];
}
