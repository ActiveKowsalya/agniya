<?php

namespace App\Http\Controllers;
use App\Models\SuiteForm;
use Illuminate\Http\Request;

class InsertController extends Controller
{
    //
    public function store(Request $req )
    {
        $data =[
            'firstname' =>$req->firstname,
            'lastname'=>$req->lastname,
            'email'=>$req->email,
            'phone'=>$req->phone,
            'companyname'=>$req->companyname,
            'country'=>$req->country,
            'custentity11'=>$req->custentity11,
            'custentity_product_need'=>$req->custentity_product_need,
            'custentity2'=>$req->custentity2,
            'custentity9'=>$req->custentity9
        ];
        $imagemodel= new SuiteForm();
		$retunresult = $imagemodel->create($data);

        if($retunresult)
        {
            $result = array('status'=>'Success','message'=>'Form Submitted Successfully');
        }
        else
        {
            $result = array('status'=>'Failure','message'=>'Form not Submitted');
        }
        return view('welcome', compact('result'));
       // return redirect()->route('welcome')->with( ['result' => $result] );
    }
}
